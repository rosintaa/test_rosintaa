<?php

namespace App\Controllers;

use App\Models\PostModel;

class Post extends BaseController
{
    
    protected $postModel;
    public function __construct()
    {
        $this->postModel = new PostModel();
    }

    public function index()
    {
        $data = [
            'title'=> 'Post',
            'post'=> $this->postModel->findAll()
        ];
        return view('/post/post', $data);
    }


    public function create(){
        $data = [
            'title'=>'Tambah Data'
        ];
        return view('/post/create', $data);
    }
  
    public function save()
    {
            $this->postModel->save([
            'title'=> $this->request->getVar('title'),
            'content'=> $this->request->getVar('date'),
            'idpost'=> $this->request->getVar('idpost')
            // 'idpost'=> url_title($this->request->getVar('nama'),'-','true')
        ]);

        return redirect()->to('/post');
    }
    public function delete($idpost) {
        $this->postModel->delete($idpost);
        return redirect()->to('/post');
    }
  
    public function edit($idpost){
        $data = [
            'title'=>'Form Edit',
            'post' => $this->postModel->where(['idpost' => $idpost])->first()
        ];
        return view('/post/edit',$data);
    }

    public function update ($idpost){
        $this->postModel->save([
            'idpost'=> $idpost,
            'nama'=> $this->request->getVar('nama'),
            // 'idpost'=> url_title($this->request->getVar('nama'),'-','true')
        ]);

        return redirect()->to('/post');
    }    
}