<?php

namespace App\Controllers;

use App\Models\AuthModel;

class Auth extends BaseController
{  
    
    public function index() 
    {
        $data = [
            'title'=>'Login'
        ];
        $ModelAkun = new \App\Models\AuthModel();
        $login = $this->request->getPost('login');
        if($login){
            $username = $this->request->getPost('username');
            $password = $this->request->getPost('password');
        }
        // if ($username == '' or $password == ''){
        //     $err= "Isi Username Password !";
        // }
        // if(empty($err)){
        //     $dataAkun = $ModelAkun->where("username", $username->first());
        //     if($dataAkun['password']!=($password)){
        //         $err = "password salah";
        //     }
        // }
        // if(empty($err)){
        //     $datasesi = [
        //         'username' => $dataAkun['username'],
        //         'password' => $dataAkun['password']
        //     ];
        //     session()->set($datasesi);
        //     return redirect()->to('post');
        // }
        return view('/login',$data);
    }
   }