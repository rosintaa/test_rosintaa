<?= $this->extend('/layouts/template') ?>


<?= $this->section('konten'); ?>

<?php foreach($nama as $na) : ?>
<ul>
    <li><?= $na['firstname'] ?></li>
    <li><?= $na['lastname'] ?></li>
</ul>
<?php endforeach; ?>

<?= $this->endSection('konten'); ?>