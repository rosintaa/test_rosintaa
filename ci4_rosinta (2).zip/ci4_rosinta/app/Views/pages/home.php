<?= $this->extend('/layouts/template'); ?>


<?= $this->section('konten'); ?>
ini home

<div>
    <?php
d($array)
?>
</div>

<?= $this->endSection('konten');?>