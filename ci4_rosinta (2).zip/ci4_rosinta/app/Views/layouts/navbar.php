<nav>
    <div class="container-nav">
        <!-- <h4>Sinta</h4> -->

        <a href="<?= base_url('/login') ?>">Login</a>
        <a href="<?= base_url('/post') ?>">Beranda</a>
        <a href="<?= base_url('/post') ?>">CRUD</a>
    </div>
</nav>      