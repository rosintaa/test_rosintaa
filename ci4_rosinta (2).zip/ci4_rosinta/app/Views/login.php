<?= $this->extend('/layouts/template') ?>

<?= $this->section('konten') ?>

<h1>Login</h1>
<br><br>
<form action="" method="post">
<label for="">Username</label>
<input type="text" name="username" id=""><br><br>
<label for="">Password</label>
<input type="text" name="password" id="">
<br><br>
<button  type="submit" name="login" value="LOGIN">Submit</button>
</form>
<?= $this->endSection('konten') ?>