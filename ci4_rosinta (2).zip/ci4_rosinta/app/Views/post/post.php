<!-- HOME -->

<!-- extend pakai file template di folder layout -->
<?= $this->extend('/layouts/template'); ?>


<!-- Section (konten) -->
<?= $this->section('konten') ?>

<h1>Post Baru</h1>
<br>
<a href="/post/create">Tambah Data</a>
<br>
<br>
<table border="1px">
    <thead>
        <tr>
            <th>ID Post</th>
            <th>Title</th>
            <th>Content</th>
            <th>Date</th>
            <th>Username</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($post as $p) : ?>
        <tr>
            <td><?= $p['idpost'] ?></td>
            <td><?= strtoupper($p['title'])  ?></td>
            <td><?= $p['content'] ?></td>
            <td><?= $p['date'] ?></td>
            <td><?= $p['username'] ?></td>
            <td>
                <a href="/post/edit/<?= $p['idpost'] ?>">Edit</a>
                <a href="/post/delete">Hapus</a>
            </td>
        </tr>
        <?php endforeach ?>
    </tbody>
</table>


<!-- endsection (konten) -->
<?= $this->endSection('konten'); ?>