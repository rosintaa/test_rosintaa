<?= $this->extend('/layouts/template') ?>

<?= $this->section('konten') ?>

<h1>Create Post</h1>
<br>
<form action="/save" method="post">

<!-- form security -->
<?= csrf_field() ?>

    <label for="nama">Title</label>
    <input type="text" name="title" id="" autofocus>
    <br><br>
    <label for="">Content</label>
    <input type="text" name="content" id="" >
    <br><br>
    <label for="">Date</label>
    <input type="date" name="date" id="" >
    <br><br>
    <button type="submit">Submit</button>
<br> <br>
</form>

<?= $this->endSection('konten') ?>