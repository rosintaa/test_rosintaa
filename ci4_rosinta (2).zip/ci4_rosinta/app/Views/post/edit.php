<?= $this->extend('/layouts/template') ?>

<?= $this->section('konten') ?>
<form action="/post/update/<?= $post['idpost'] ?>" method="post">

    <label for="nama">Title</label>
    <input type="text" name="title" id="" value="<?= $post['title']?>">
    <br><br>
    <label for="">Content</label>
    <input type="text" name="content" id="" value="<?= $post['content']?>">
    <br><br>
    <label for="">Date</label>
    <input type="date" name="date" id="" value="<?= $post['date']?>">
    <br><br>
    <button type="submit">Ubah</button>
<br> <br>
</form>

<?= $this->endSection('konten') ?>